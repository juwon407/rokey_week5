// generated from rosidl_generator_c/resource/idl.h.em
// with input from boxproject_interfaces:action/TaskAction.idl
// generated code does not contain a copyright notice

#ifndef BOXPROJECT_INTERFACES__ACTION__TASK_ACTION_H_
#define BOXPROJECT_INTERFACES__ACTION__TASK_ACTION_H_

#include "boxproject_interfaces/action/detail/task_action__struct.h"
#include "boxproject_interfaces/action/detail/task_action__functions.h"
#include "boxproject_interfaces/action/detail/task_action__type_support.h"

#endif  // BOXPROJECT_INTERFACES__ACTION__TASK_ACTION_H_
