// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef BOXPROJECT_INTERFACES__ACTION__TASK_ACTION_HPP_
#define BOXPROJECT_INTERFACES__ACTION__TASK_ACTION_HPP_

#include "boxproject_interfaces/action/detail/task_action__struct.hpp"
#include "boxproject_interfaces/action/detail/task_action__builder.hpp"
#include "boxproject_interfaces/action/detail/task_action__traits.hpp"

#endif  // BOXPROJECT_INTERFACES__ACTION__TASK_ACTION_HPP_
