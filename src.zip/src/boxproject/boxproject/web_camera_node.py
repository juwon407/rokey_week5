import cv2
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

class BasicCameraNode(Node):
    def __init__(self):
        super().__init__('camera_node')
        
        # OpenCV - ROS 메시지 변환 브리지
        self.bridge = CvBridge()
        
        # 퍼블리셔 생성
        self.publisher = self.create_publisher(Image, 'webcam/image_raw', 10)
        
        # 카메라 초기화
        self.camera = None
        self.camera_index = None
        self.find_and_connect_camera()
        
        # 카메라 연결 확인
        if not self.camera:
            self.get_logger().error("카메라를 연결할 수 없습니다. 노드를 종료합니다.")
            return
        
        # 주기적인 타이머 설정 (30FPS 기준)
        self.timer_period = 0.01  # 30 FPS
        self.timer = self.create_timer(self.timer_period, self.capture_and_publish_frame)

    def find_and_connect_camera(self):
        """사용 가능한 카메라를 찾아 연결"""
        self.get_logger().info("사용 가능한 카메라를 검색하는 중...")
        for index in range(10):  # 최대 10개의 카메라 인덱스 확인
            cap = cv2.VideoCapture(index)
            if cap.isOpened():
                cap.release()
                self.camera_index = index
                self.camera = cv2.VideoCapture(self.camera_index)
                if self.camera.isOpened():
                    self.get_logger().info(f"카메라에 연결됨: /dev/video{self.camera_index}")
                    return True
        self.camera = None  # 카메라 연결 실패
        return False

    def capture_and_publish_frame(self):
        """카메라에서 프레임 캡처 후 퍼블리시"""
        if not self.camera or not self.camera.isOpened():
            self.get_logger().warning("카메라가 연결되어 있지 않습니다.")
            return

        ret, frame = self.camera.read()
        if not ret:
            self.get_logger().warning("프레임 캡처 실패")
            return
        
        try:
            # OpenCV 이미지를 ROS 메시지로 변환하여 퍼블리시
            msg = self.bridge.cv2_to_imgmsg(frame, encoding='bgr8')
            self.publisher.publish(msg)
        except Exception as e:
            self.get_logger().error(f"프레임 변환/퍼블리시 에러: {e}")

    def destroy_node(self):
        """노드 종료 시 리소스 정리"""
        if self.camera and self.camera.isOpened():
            self.camera.release()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = BasicCameraNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
