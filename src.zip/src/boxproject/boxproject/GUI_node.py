# 기본 import
import sys
import json

# cv 라이브러리
from cv_bridge import CvBridge
import cv2  # OpenCV 라이브러리

# ros2 라이브러리
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import Image
from std_msgs.msg import String

# pyqt5 라이브러리
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLineEdit, QPushButton, QLabel, QDesktopWidget, QMessageBox, QDialog
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt, QTimer, QTime, QThread, pyqtSignal

# 이메일 전송 라이브러리
import smtplib
from email.mime.text import MIMEText



# ROS2 로직 관리 클래스
class GuiNode(Node):
    def __init__(self, email=None, robot_status_label=None, media_label=None, log_textbox=None):
        super().__init__('gui_node')

        self.email = email  # 로그인에서 저장된 이메일
        self.warning_flag = False  # 이메일 전송 플래그 (경고 상태)
        self.connected_flag = True  # 연결 상태 플래그

        # webcam images qos 설정
        web_qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,  # 퍼블리셔와 동일한 QoS 설정
            depth=10
        )

        # 퍼블리셔 생성
        self.conveyor_publisher = self.create_publisher(String, 'conveyor_state', 10)   # 컨베이어 상태 퍼블리셔
        self.emergency_publisher = self.create_publisher(String, 'emergency_stop', 10)  # 비상정지 퍼블리셔

        # 컨베이어 상태 초기화
        self.conveyor_state = {
            "status": "auto",
            "move": "False"
        }

        # 서브스크라이버 생성
        # 1. 로봇 상태 서브스크라이버
        self.robot_status_label = robot_status_label
        self.create_subscription(String, 'robot_status', self.robot_status_callback, 10)

        # 2. 웹캠 스트리밍 서브스크라이버
        self.media_label = media_label
        self.bridge = CvBridge()  # OpenCV와 ROS 메시지 변환을 위한 브리지 객체
        self.create_subscription(Image, 'webcam/image_raw', self.webcam_callback, web_qos_profile)

        # 3. LOG 서브스크라이버
        self.log_textbox = log_textbox
        self.create_subscription(String, 'log_mesg', self.log_mesg_callback, 10)

    def robot_status_callback(self, msg):
        """로봇 상태를 업데이트"""
        self.robot_status_label.setText(msg.data)
        self.get_logger().info(f"Received robot status: {msg.data}")

    def log_mesg_callback(self, msg):
        """로그 메시지를 처리"""
        log_message = msg.data
        self.get_logger().info(f"Received log message: {log_message}")

        if "[경고] 카메라 연결이 끊어졌습니다." in log_message:
            if not self.warning_flag:  # 경고 플래그가 False일 때만 실행
                self.warning_flag = True
                self.connected_flag = False
                self.send_email("카메라 상태 경고", "카메라 연결이 끊어졌습니다. 다시 연결을 시도 중입니다.")
        
        elif "[정보] 카메라에 연결됨" in log_message:
            if not self.connected_flag:  # 연결 상태가 갱신되었을 때만 실행
                self.warning_flag = False
                self.connected_flag = True
                self.send_email("카메라 상태 업데이트", "카메라가 정상적으로 다시 연결되었습니다.")

        # 로그 텍스트 업데이트
        self.log_textbox.clear()
        self.log_textbox.append(log_message)

#---------------이메일 전송 부분
    def send_email(self, subject, message):
        """이메일 전송 함수 (쓰레드 사용)"""
        if not self.email:
            self.get_logger().warning("이메일이 설정되지 않았습니다.")
            return

        # 이메일 전송 쓰레드 생성
        self.email_thread = EmailSenderThread(self.email, subject, message)
        self.email_thread.finished.connect(self.on_email_sent)  # 성공 시 콜백 연결
        self.email_thread.error.connect(self.on_email_error)    # 에러 시 콜백 연결
        self.email_thread.start()  # 쓰레드 시작

    def on_email_sent(self, success):
        if success:
            self.get_logger().info(f"이메일 전송 성공: {self.email}")
        else:
            self.get_logger().warning(f"이메일 전송 실패: {self.email}")

    def on_email_error(self, error_message):
        self.get_logger().error(f"이메일 전송 에러: {error_message}")
#--------------------이메일 전송 끝

    def webcam_callback(self, msg):
        """웹캠 이미지를 QLabel에 표시"""
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb_image.shape
            bytes_per_line = ch * w
            qt_image = QtGui.QImage(rgb_image.data, w, h, bytes_per_line, QtGui.QImage.Format_RGB888)
            pixmap = QtGui.QPixmap.fromImage(qt_image)
            self.media_label.setPixmap(pixmap)
        except Exception as e:
            self.get_logger().error(f"Failed to process webcam image: {e}")

    def publish_conveyor_state(self):
        """컨베이어 상태를 퍼블리시"""
        msg = String()
        msg.data = json.dumps(self.conveyor_state)
        self.conveyor_publisher.publish(msg)
        self.get_logger().info(f"Published: {msg.data}")

    def publish_emergency_stop(self):
        """비상정지 메시지를 퍼블리시"""
        msg = String()
        msg.data = "Emergency Stop Activated"
        self.emergency_publisher.publish(msg)
        self.get_logger().info("Emergency stop message published.")

# main 인터페이스 및 이벤트 관리 클래스
class MainApp(QtWidgets.QDialog):
    def __init__(self, gui_node):
        super().__init__()
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)

        # ROS2 노드
        self.gui_node = gui_node

        # GuiNode에 UI 요소 연결
        gui_node.robot_status_label = self.ui.robot_status_label
        gui_node.media_label = self.ui.media_label
        gui_node.log_textbox = self.ui.log_textbox

        # 타이머 초기화
        self.initTimer()

        # ROS2 스핀 타이머
        self.ros_timer = QTimer(self)
        self.ros_timer.timeout.connect(self.spin_ros2)
        self.ros_timer.start(30)  # 50ms마다 스핀 실행

        # 버튼 클릭 이벤트 연결
        self.ui.emergencystop_button.clicked.connect(self.handle_emergencystop_button)
        self.ui.job_start_button.clicked.connect(self.handle_job_start_button)
        self.ui.job_pause_button.clicked.connect(self.handle_job_pause_button)
        self.ui.job_resume_button.clicked.connect(self.handle_job_resume_button)
        self.ui.job_reset_button.clicked.connect(self.handle_job_reset_button)
        self.ui.email_save_button.clicked.connect(self.handle_email_save_button)
        self.ui.collect_data_button.clicked.connect(self.handle_collect_data_button)

        # 컨베이어 수동 작동 이벤트 연결
        self.ui.conveyor_control_radio.clicked.connect(self.handle_conveyor_control_radio) # 수동 작동 라디오 버튼 이벤트
        self.ui.conveyor_move_button.pressed.connect(self.handle_conveyor_move_start)
        self.ui.conveyor_move_button.released.connect(self.handle_conveyor_move_stop)

#------------------------------컨베이어 수동 조작 관련 시작
    def handle_conveyor_control_radio(self):
        """컨베이어 수동 조작 라디오 버튼 클릭"""
        print("컨베이어 수동 조작 라디오 버튼 클릭")
        self.gui_node.conveyor_state["status"] = "manual"
        self.gui_node.conveyor_state["move"] = "False"  # 기본값
        self.gui_node.publish_conveyor_state()
        self.ui.conveyor_move_button.setEnabled(True)  # 작동 버튼 활성화

    def handle_conveyor_move_start(self):
        """컨베이어 작동 버튼 누름"""
        print("컨베이어 작동 버튼 누름")
        self.gui_node.conveyor_state["move"] = "True"
        self.gui_node.publish_conveyor_state()

    def handle_conveyor_move_stop(self):
        """컨베이어 작동 버튼에서 손을 뗌"""
        print("컨베이어 작동 버튼에서 손 뗌")
        self.gui_node.conveyor_state["move"] = "False"
        self.gui_node.publish_conveyor_state()
#------------------------------컨베이어 수동 조작 관련 끝
    

#------------------------작업 소요 시간 관련 시작---------------------
    def initTimer(self):
        # 작업 소요 시간 초기화
        self.processing_timer = QTimer(self)
        self.processing_timer.timeout.connect(self.update_time)
        self.elapsed_time = QTime(0, 0, 0)    # 00:00:00
        self.is_paused = False

    
    def update_time(self):
        #print("update")
        self.elapsed_time = self.elapsed_time.addSecs(1)
        self.ui.processing_time_label.setText(f"작업 소요 시간 - {self.elapsed_time.toString('hh:mm:ss')}")

    def control_timer(self, command=None):
        if command is None:
            print(f"control_timer 함수의 명령이 {command} 입니다.")
            return
        
        if command == "start":
            self.elapsed_time = QTime(0, 0, 0)  # 시간 초기화
            self.ui.processing_time_label.setText("작업 소요 시간 - 00:00:00")
            self.processing_timer.start(1000)  # 1초 간격으로 타이머 실행
            self.is_paused = False
            #print("Timer started")

            if self.processing_timer.isActive():
                print("processing_timer is running")
            else:
                print("processing_timer is not running")
        
        elif command == "stop":
            self.processing_timer.stop()
            self.is_paused = False
            #print("P_Timer stopped")

        elif command == "pause":
            if self.processing_timer.isActive():
                self.processing_timer.stop()
                self.is_paused = True
                #print("P_Timer paused")

        elif command == "resume":
            if self.is_paused:
                self.processing_timer.start(1000)
                self.is_paused = False
                #print("P_Timer resumed")

        elif command == "reset":
            self.processing_timer.stop()
            self.elapsed_time = QTime(0, 0, 0)  # 시간 초기화
            self.ui.processing_time_label.setText("작업 소요 시간 - 00:00:00")
            self.is_paused = False
            #print("P_Timer reset")
        
        else:
            print(f"control_timer 함수의 알 수 없는 명령: {command}")
    #------------------------작업 소요 시간 관련 끝---------------------

    def spin_ros2(self):
        rclpy.spin_once(self.gui_node, timeout_sec=0.01)

    def closeEvent(self, event):
        self.gui_node.destroy_node()
        rclpy.shutdown()
        super().closeEvent(event)




    # 이벤트 핸들러
    def handle_emergencystop_button(self):
        print("비상 정지 버튼 클릭")
        self.control_timer("stop")
        self.gui_node.publish_emergency_stop()

    def handle_job_start_button(self):
        print("JOB 시작 버튼 클릭")
        self.control_timer("start")

    def handle_job_pause_button(self):
        print("JOB 일시 정지 버튼 클릭")
        self.control_timer("pause")

    def handle_job_resume_button(self):
        print("JOB 작업 재개 버튼 클릭")
        self.control_timer("resume")

    def handle_job_reset_button(self):
        print("JOB 리셋 버튼 클릭")
        self.control_timer("reset")

    def handle_email_save_button(self):
        print("이메일 저장 버튼 클릭")

    def handle_collect_data_button(self):
        print("학습 데이터 수집 버튼 클릭")

# 로그인 창
class Login(QWidget):
    def __init__(self, gui_node):
        super().__init__()
        self.gui_node = gui_node
        self.email = None  # 이메일 저장
        self.initUI()

    def initUI(self):
        self.setWindowTitle('시스템 로그인')
        self.resize(450, 350)
        self.setMinimumSize(300, 250)  # 최소 창 크기 설정
        self.setStyleSheet("background-color: #F5F6F7;")

        # 창을 화면에 배치
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

        layout = QVBoxLayout()
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        layout.addStretch(1)  # 상단 여백

        # 로그인 제목
        title_label = QLabel('로그인')
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setFont(QFont('Arial', 24, QFont.Bold))
        layout.addWidget(title_label)

        layout.addStretch(1)  # 제목과 입력 필드 사이 여백

        # 아이디 입력
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("이메일")
        self.email_input.setStyleSheet("""
            QLineEdit {
                border: 1px solid #DADADA;
                border-radius: 5px;
                padding: 10px;
                font-size: 16px;
                background-color: white;
            }
        """)
        layout.addWidget(self.email_input)

        # 비밀번호 입력
        self.pw_input = QLineEdit()
        self.pw_input.setPlaceholderText("비밀번호")
        self.pw_input.setEchoMode(QLineEdit.Password)
        self.pw_input.setStyleSheet("""
            QLineEdit {
                border: 1px solid #DADADA;
                border-radius: 5px;
                padding: 10px;
                font-size: 16px;
                background-color: white;
            }
        """)
        layout.addWidget(self.pw_input)

        layout.addStretch(1)  # 입력 필드와 버튼 사이 여백

        # 로그인 버튼
        login_button = QPushButton("로그인")
        login_button.setStyleSheet("""
            QPushButton {
                background-color: #1E90FF;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 15px;
                font-size: 18px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #5ACCFF;
            }
        """)
        login_button.clicked.connect(self.login)
        layout.addWidget(login_button)

        layout.addStretch(1)  # 하단 여백

        self.setLayout(layout)

    def keyPressEvent(self, event):
        """창 전체에서 키 이벤트를 처리"""
        if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
            self.login()

    def login(self):
        if self.pw_input.text() == "rokey":
            self.email = self.email_input.text()  # 이메일 저장
            if not self.email:  # 이메일이 빈 문자열인 경우 처리
                QMessageBox.warning(self, "로그인 실패", "이메일을 입력하세요.")
                return
            self.gui_node.email = self.email  # 이메일 전달
            self.gui_node.get_logger().info(f"로그인된 이메일: {self.email}")  # 이메일 확인용 로그
            QMessageBox.information(self, "로그인 성공", f"이메일: {self.email}로 시스템 접속")
            self.open_main_window()
        else:
            QMessageBox.warning(self, "로그인 실패", "비밀번호가 올바르지 않습니다.")

    def open_main_window(self):
        self.gui_node.email = self.email  # 이메일 전달
        self.main_window = MainApp(self.gui_node)
        self.main_window.show()
        self.close()

# 메인 ui 클래스
class Ui_Dialog(object):
    def setupUi(self, Dialog):
        # 메인 페이지
        self.Dialog = Dialog
        Dialog.setObjectName("Dialog")
        Dialog.resize(774, 768)
        
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth())
        Dialog.setSizePolicy(sizePolicy)
        Dialog.setStyleSheet("background-color: #F5F6F7;")

        # JOB 작업 그룹
            # JOB 선택 박스
        self.job_comboBox = QtWidgets.QComboBox(Dialog)
        self.job_comboBox.setGeometry(QtCore.QRect(320, 480, 271, 31))
        self.job_comboBox.setObjectName("job_comboBox")
        self.job_comboBox.addItem("")
        self.job_comboBox.addItem("")
        self.job_comboBox.addItem("")

            # JOB 시작 버튼
        self.job_start_button = QtWidgets.QPushButton(Dialog)
        self.job_start_button.setGeometry(QtCore.QRect(320, 520, 131, 31))
        self.job_start_button.setObjectName("job_start_button")

            # JOB 일시정지 버튼
        self.job_pause_button = QtWidgets.QPushButton(Dialog)
        self.job_pause_button.setGeometry(QtCore.QRect(600, 480, 141, 31))
        self.job_pause_button.setEnabled(False)
        self.job_pause_button.setObjectName("job_pause_button")

            # JOB 동작 재개 버튼
        self.job_resume_button = QtWidgets.QPushButton(Dialog)
        self.job_resume_button.setGeometry(QtCore.QRect(600, 520, 141, 31))
        self.job_resume_button.setEnabled(False)
        self.job_resume_button.setObjectName("job_resume_button")

            # JOB 초기화 버튼
        self.job_reset_button = QtWidgets.QPushButton(Dialog)
        self.job_reset_button.setGeometry(QtCore.QRect(320, 560, 421, 31))
        # self.job_reset_button.setEnabled(False)
        self.job_reset_button.setObjectName("job_reset_button")

            # JOB 정지 버튼
        self.job_stop_button = QtWidgets.QPushButton(Dialog)
        self.job_stop_button.setEnabled(False)
        self.job_stop_button.setGeometry(QtCore.QRect(460, 520, 131, 31))
        self.job_stop_button.setObjectName("job_stop_button")

        # 비상정지 버튼
        self.emergencystop_button = QtWidgets.QPushButton(Dialog)
        self.emergencystop_button.setGeometry(QtCore.QRect(40, 604, 701, 81))
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.emergencystop_button.setFont(font)
        self.emergencystop_button.setAutoFillBackground(False)
        self.emergencystop_button.setObjectName("emergencystop_button")

        # 로봇 상태 라벨
        self.robot_status_label = QtWidgets.QLabel(Dialog)
        self.robot_status_label.setGeometry(QtCore.QRect(40, 10, 701, 61))
        font = QtGui.QFont()
        font.setPointSize(32)
        self.robot_status_label.setFont(font)
        self.robot_status_label.setFrameShape(QtWidgets.QFrame.Box)
        self.robot_status_label.setAlignment(QtCore.Qt.AlignCenter)
        self.robot_status_label.setObjectName("robot_status_label")

        # 작업 소요 시간 라벨
        self.processing_time_label = QtWidgets.QLabel(Dialog)
        self.processing_time_label.setGeometry(QtCore.QRect(320, 450, 291, 23))
        self.processing_time_label.setObjectName("processing_time_label")

        # 영상 출력 하는 라벨
        self.media_label = QtWidgets.QLabel(Dialog)
        self.media_label.setGeometry(QtCore.QRect(40, 80, 701, 361))
        font = QtGui.QFont()
        font.setPointSize(30)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.media_label.setFont(font)
        self.media_label.setAutoFillBackground(False)
        self.media_label.setFrameShape(QtWidgets.QFrame.Panel)
        self.media_label.setFrameShadow(QtWidgets.QFrame.Plain)
        self.media_label.setAlignment(QtCore.Qt.AlignCenter)
        self.media_label.setObjectName("media_label")

        # 학습 데이터 수집 버튼
        self.collect_data_button = QtWidgets.QPushButton(Dialog)
        self.collect_data_button.setGeometry(QtCore.QRect(40, 540, 261, 51))
        self.collect_data_button.setObjectName("collect_data_button")

        # 이메일 그룹
            # 이메일 입력 텍스트 박스
        self.email_textbox = QtWidgets.QTextEdit(Dialog)
        self.email_textbox.setGeometry(QtCore.QRect(400, 730, 241, 31))
        self.email_textbox.setObjectName("email_textbox")

            # 이메일 저장 버튼
        self.email_save_button = QtWidgets.QPushButton(Dialog)
        self.email_save_button.setGeometry(QtCore.QRect(650, 730, 89, 31))
        self.email_save_button.setObjectName("email_save_button")

            # "관리자 이메일"을 나타내는 라벨 수정 불필요
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(300, 730, 91, 31))
        self.label_3.setObjectName("label_3")

        # 컨베이어 수동 조작 그룹
            # 컨베이어 수동 조작 체크 버튼
        self.conveyor_control_radio = QtWidgets.QRadioButton(Dialog)
        self.conveyor_control_radio.setGeometry(QtCore.QRect(40, 450, 141, 23))
        self.conveyor_control_radio.setObjectName("conveyor_control_radio")
        self.conveyor_move_button = QtWidgets.QPushButton(Dialog)
        self.conveyor_move_button.setEnabled(False)
        self.conveyor_move_button.setGeometry(QtCore.QRect(40, 480, 261, 51))
        self.conveyor_move_button.setObjectName("conveyor_move_button")


        # 로그창 관련
        self.log_textbox = QtWidgets.QTextEdit(Dialog)
        self.log_textbox.setGeometry(QtCore.QRect(40, 690, 701, 31))
        self.log_textbox.setAlignment(QtCore.Qt.AlignCenter)
        self.log_textbox.setObjectName("log_textbox")
        self.log_textbox.setReadOnly(True)
        self.log_textbox.setStyleSheet("background-color: white; color: black;")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate

        # 화면에 출력될 텍스트
        Dialog.setWindowTitle(_translate("Dialog", "Team 5"))

        # 영상 출력할 라벨
        self.media_label.setText(_translate("Dialog", "Media"))

        # 로봇 상태 라벨
        self.robot_status_label.setText(_translate("Dialog", "robot status"))

        # 비상 정지 버튼
        self.emergencystop_button.setText(_translate("Dialog", "EmergencyStop"))

        # JOB 관련
            # JOB 작업 소요 시간 라벨
        self.processing_time_label.setText(_translate("Dialog", "작업 소요 시간 - 00:00:00"))

            # JOB 버튼들
        self.job_start_button.setText(_translate("Dialog", "START"))
        self.job_stop_button.setText(_translate("Dialog", "STOP"))
        self.job_pause_button.setText(_translate("Dialog", "PAUSE"))
        self.job_resume_button.setText(_translate("Dialog", "RESUME"))
        self.job_reset_button.setText(_translate("Dialog", "RESET"))

            # JOB 선택 콤보 박스 (밑에 추가하면 JOB 추가 가능)
        self.job_comboBox.setItemText(0, _translate("Dialog", "Job1"))
        self.job_comboBox.setItemText(1, _translate("Dialog", "Job2"))
        self.job_comboBox.setItemText(2, _translate("Dialog", "Job3"))

        # 관리자 이메일 관련
        self.email_save_button.setText(_translate("Dialog", "저장"))
        self.label_3.setText(_translate("Dialog", "관리자 이메일 "))

        # 학습 데이터 수집
        self.collect_data_button.setText(_translate("Dialog", "학습 데이터 수집"))
        
        # 컨베이어 수동 조작
        self.conveyor_control_radio.setText(_translate("Dialog", "컨베이어 수동 조작"))
        self.conveyor_move_button.setText(_translate("Dialog", "컨베이어 작동"))

# 이메일 전송 쓰레드 클래스
class EmailSenderThread(QThread):
    finished = pyqtSignal(bool)  # 작업 완료 신호 (성공 여부 반환)
    error = pyqtSignal(str)      # 에러 신호

    def __init__(self, email, subject, message, parent=None):
        super().__init__(parent)
        self.email = email
        self.subject = subject
        self.message = message

    def run(self):
        """이메일 전송 작업"""
        smtp_server = "smtp.gmail.com"
        smtp_port = 587
        sender_email = "doosan.rokey.b5@gmail.com"
        sender_password = "tcbd gasi edjk sazv"

        msg = MIMEText(self.message)
        msg['Subject'] = self.subject
        msg['From'] = sender_email
        msg['To'] = self.email

        try:
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, self.email, msg.as_string())
            server.quit()
            self.finished.emit(True)  # 성공 신호
        except Exception as e:
            self.error.emit(str(e))  # 에러 신호

def main(args=None):
    rclpy.init(args=args)  # ROS2 초기화

    # ROS2 노드 생성
    gui_node = GuiNode()  # robot_status_label과 media_label은 MainApp에서 설정

    app = QApplication(sys.argv)

    # 로그인창 생성
    login_window = Login(gui_node)
    login_window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()